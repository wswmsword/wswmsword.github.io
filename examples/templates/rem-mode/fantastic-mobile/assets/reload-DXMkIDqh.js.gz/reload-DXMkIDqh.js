import{d as o,h as t,i as n,u as r,o as a}from"./index-NBq_IxQ4.js";const p=o({__name:"reload",setup(s){const e=r();return t(()=>{e.go(-1)}),(c,u)=>(a(),n("div"))}});export{p as default};
